require File.dirname(__FILE__) + '/../test_helper'

class BlogPostTest < Test::Unit::TestCase
  fixtures :blog_posts

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
