# This is my site configuration file.
module Site
CONFIG = {
:blogname => 'My Simple Blog'
}
end
