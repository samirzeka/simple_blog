class UsersController < ApplicationController

	layout "staff"
	
  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @user_pages, @users = paginate :users, :per_page => 10
  end



  def manage
	list
	if request.get? && params[:id].blank? #new
	@user = User.new
	elsif request.post? && params[:id].blank? #create
	@user = User.new(params[:user])
    if @user.save
      flash[:notice] = 'User was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
	elsif request.get? && !params[:id].blank? #edit
	@user = User.find(params[:id])
	elsif request.post? && !params[:id].blank? #update
	@user = User.find(params[:id])
    if @user.update_attributes(params[:user])
      flash[:notice] = 'User was successfully updated.'
      redirect_to :action => 'list'
    else
      render :action => 'edit'
    end
	end
  end


  def destroy
    User.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
