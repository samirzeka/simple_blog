class StaffController < ApplicationController
layout "staff"

  def index
  end

  def login
  end

  def menu
  end

  def logout
  end
end
