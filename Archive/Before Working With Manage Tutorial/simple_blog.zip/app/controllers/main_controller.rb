class MainController < ApplicationController

  def index
  end

  def list
  end

  def category
  end

  def archive
  end

  def view_post
  end
end
