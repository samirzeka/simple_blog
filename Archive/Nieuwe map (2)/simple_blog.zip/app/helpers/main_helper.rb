module MainHelper
	def prepare_post_body
		content = h(content)
		content = strip_tags(content)
		content = simple_format(content)
		content = auto_link(content)
		return content
	end
end
