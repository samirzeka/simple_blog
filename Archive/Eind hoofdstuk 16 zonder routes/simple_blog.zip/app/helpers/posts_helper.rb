module PostsHelper
	include MainHelper
end
